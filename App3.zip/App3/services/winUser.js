const winUser =  (req,resp)=>{
    resp.send('Uzytkownicy windows</br>' +
    'aby uruchomic serwer node.js na wlasnym porcie poprzez zminenna ENW<br/>' +
    'wpis: <code>$env:PORT=1313; node app.js</code></br>' + 'Dla nie windows: <code>export PORT=1234</code>');
};
module.exports = winUser;