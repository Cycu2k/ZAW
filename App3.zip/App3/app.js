const http = require('express');
const conf = require('./etc/conf');

//const name = 'MiniApp';
//const port = 1313;

const app = http()
/*
app.get('/',(req,resp)=>{
    resp.send('MiApp home page');
    console.log('homepage');    
});

app.get('win-user', (req,resp)=>{
    resp.send('Uzytkownicy windows</br>' +
    'aby uruchomic serwer node.js na wlasnym porcie poprzez zminenna ENW<br/>' +
    'wpis: <code>$env:PORT=1313; node app.js</code></br>' + 'Dla nie windows: <code>export PORT=1234</code>');
});
*/
const router = require('./routes/api');
app.use('/',router);

app.listen(conf.port);
console.log("App: "+ conf.name);
console.log('http://localhost:' + conf.port);



/*let author = "Cyprian Górny";



const meta = require('./app2-head');

meta.init();
meta.display();
*/