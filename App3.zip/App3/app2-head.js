let meta = {};

const init = ()=>{
    console.log('init()');
    meta.author = 'PW';
    meta.class = '4Tr';
    meta.ver = '1.0';
    meta.portNm = '1234';
}

const display =  ()=>{
    console.log(meta);
}

module.exports = init;
module.exports = { init, display };
