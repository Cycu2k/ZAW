const http = require('express');

const rt = http.Router();

rt.get('/', (req,resp)=>{
    resp.send('Strona głowna - witamy');
    console.log('New connection');
});


const selfTest = require('../services/selfTest');
rt.get('/self-test',selfTest);

const winUser = require('../services/winUser');
rt.get('/win-user',winUser );

module.exports = rt