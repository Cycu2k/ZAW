module.exports = {
    name: 'MiniApp',
    port: process.env.PORT || 1313,
}