const container = document.getElementById('container');
const squareSize = 50;

function generateRandomElements(){
    const elementCountInput = document.getElementById('elementCounter');
    const numberOfSquares = parseInt(elementCountInput.value) || 0;
    
    container.innerHTML = '';

    const positons = [];

    for(let i =0; i < numberOfSquares; i++){
        const square = document.createElement('div');
        square.classList.add('square');

        let posX, posY, isOverlapping;

        do{
            isOverlapping = false;

            posX = Math.random() * (container.offsetWidth - squareSize);
            posY = Math.random() * (container.offsetHeight - squareSize);

            for(const pos of positons){
                const distX = Math.abs(posX - pos.x);
                const distY = Math.abs(posY - pos.y);

                if(distX < squareSize && distY < squareSize){
                    isOverlapping = true;
                    break;
                }
            }
        }while(isOverlapping){
            square.style.left = `${posX}px`;
            square.style.top = `${posY}px`;

            positons.push({x: posX, y: posY});

            container.appendChild(square);
        }
    }
    
}
window.onload = generateRandomElements;